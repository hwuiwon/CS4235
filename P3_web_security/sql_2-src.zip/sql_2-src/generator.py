import hashlib, random, re

while True:
    limit = 2147483647
    rand = str(random.randint(0, limit)) + str(random.randint(0, limit)) + str(random.randint(0, limit))
    exists = re.search(r"'='", str(hashlib.md5(rand.encode()).digest()))

    if exists:
        print(rand)
        break
